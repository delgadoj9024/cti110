# taking input from user
user_name = input()
# Displaying the welcome message using string formatting
print("Hello {name} and welcome to CS Online!".format(name=user_name))